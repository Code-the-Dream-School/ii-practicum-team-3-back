import User from "../models/userModel.js";

export async function findByEmailOrFullName(email, firstName, lastName) {
  if (!email || !firstName || !lastName) {
    throw new Error("Email, first name and last name are required");
  }
  return await User.findOne({
    $or: [{ email }, { $and: [{ firstName }, { lastName }] }],
  }).lean();
}

export async function findByEmail(email, includePassword = false) {
  if (!email) throw new Error("Email is required");
  if (includePassword) {
    return await User.findOne({ email }).select("+password");
  }
  return await User.findOne({ email });
}

export async function getUserById(userId, includeRefreshToken = false) {
  if (!userId) throw new Error("User ID is required");
  if (includeRefreshToken) {
    return await User.findById(userId).select("+refreshToken");
  }
  return await User.findById(userId);
}

export async function getAllUsers() {
  return await User.find({});
}

export async function getUserByIdWithPassword(userId) {
  return await User.findById(userId).select("+password");
}

export async function createUser(userData) {
  if (!userData) throw new Error("User data is required");
  const user = await User.create(userData);
  return user;
}

export async function updateUser(userId, updateData) {
  if (!userId) throw new Error("User ID is required");
  if (!updateData) throw new Error("Update data is required");
  const user = await User.findByIdAndUpdate(userId, updateData, {
    new: true,
    runValidators: true,
  });
  return user;
}

export async function deleteUser(userId) {
  if (!userId) throw new Error("User ID is required");
  const user = await User.findByIdAndDelete(userId);
  return user;
}

export {
  findByEmailOrFullName,
  findByEmail,
  getUserById,
  getAllUsers,
  getUserByIdWithPassword,
  createUser,
  updateUser,
  deleteUser,
};
